package com.example.vinay.hack_emotion;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.microsoft.projectoxford.emotion.contract.RecognizeResult;

import java.util.HashMap;
import java.util.List;

public class StartCon extends AppCompatActivity {
    TextView mEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_con);
        mEditText=(TextView)findViewById(R.id.mEditText);
        Intent i=getIntent();
        Bundle b=i.getExtras();
        List<RecognizeResult> result=b.getParcelable("k1");
        int count=0;
        HashMap<String,Double> emot = new HashMap<>();
        for (RecognizeResult r : result) {


            mEditText.append(String.format("\nFace #%1$d \n", count));
            mEditText.append(String.format("\t anger: %1$.5f\n", r.scores.anger));
            emot.put("Anger", Double.valueOf(String.format("%1$.5f", r.scores.anger)));
            //emot[0]=Double.parseDouble(String.format(" %1$.5f", r.scores.anger));
            mEditText.append(String.format("\t contempt: %1$.5f\n", r.scores.contempt));
            emot.put("Contempt", Double.valueOf(String.format("%1$.5f", r.scores.contempt)));
            mEditText.append(String.format("\t disgust: %1$.5f\n", r.scores.disgust));
            emot.put("Disgust", Double.valueOf(String.format("%1$.5f", r.scores.disgust)));
            mEditText.append(String.format("\t fear: %1$.5f\n", r.scores.fear));
            emot.put("Fear", Double.valueOf(String.format("%1$.5f", r.scores.fear)));
            mEditText.append(String.format("\t happiness: %1$.5f\n", r.scores.happiness));
            emot.put("Happy", Double.valueOf(String.format("%1$.5f", r.scores.happiness)));
            mEditText.append(String.format("\t neutral: %1$.5f\n", r.scores.neutral));
            emot.put("Neutral", Double.valueOf(String.format("%1$.5f", r.scores.neutral)));
            mEditText.append(String.format("\t sadness: %1$.5f\n", r.scores.sadness));
            emot.put("Sad", Double.valueOf(String.format("%1$.5f", r.scores.sadness)));
            mEditText.append(String.format("\t surprise: %1$.5f\n", r.scores.surprise));
            emot.put("Surprize", Double.valueOf(String.format("%1$.5f", r.scores.surprise)));
//            mEditText.append(String.format("\t face rectangle: %d, %d, %d, %d", r.faceRectangle.left, r.faceRectangle.top, r.faceRectangle.width, r.faceRectangle.height));
//            faceCanvas.drawRect(r.faceRectangle.left,
//                    r.faceRectangle.top,
//                    r.faceRectangle.left + r.faceRectangle.width,
//                    r.faceRectangle.top + r.faceRectangle.height,
//                    paint);
            count++;
        }
    }
}
